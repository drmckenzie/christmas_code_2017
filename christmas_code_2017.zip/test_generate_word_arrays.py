# scraping the input
import generate_word_arrays

print("Please input string to tree-ify")
t= input()
generate_word_arrays.generate_word_arrays(t)