# scraping the input
import generate_diagonal_list

print("testing")
#t= input()
t= []
t.append("abc")
t.append("def")
t.append("ghi")
t.append("jkl")

t= []
t.append("abc")
t.append("bcd")
t.append("cde")
t.append("def")

generate_diagonal_list.generate_diagonal_list(t)